const express = require('express');
const axios = require('axios');
const requireAuth = require('../middleware/auth');
const User = require('../models/User');
const Generation = require('../models/Generation');

const openai = require('../services/openai');
const runway = require('../services/runway');
const stability = require('../services/stability');
const luma = require('../services/luma');

const router = express.Router();

// Simple credit costs per job type - tune to your margins.
const CREDIT_COST = {
  'text-to-image': 2,
  'text-to-video': 10,
  'image-to-video': 8,
  remix: 6,
};

async function spendCredits(userId, amount) {
  const user = await User.findById(userId);
  if (!user) throw new Error('User not found');
  if (user.credits < amount) {
    const err = new Error('Not enough credits - please top up.');
    err.code = 'INSUFFICIENT_CREDITS';
    throw err;
  }
  user.credits -= amount;
  await user.save();
  return user.credits;
}

// POST /api/generate/text-to-image
router.post('/text-to-image', requireAuth, async (req, res) => {
  const { prompt, provider = 'openai', size } = req.body;
  const cost = CREDIT_COST['text-to-image'];

  try {
    await spendCredits(req.userId, cost);
    const gen = await Generation.create({
      user: req.userId,
      type: 'text-to-image',
      provider,
      prompt,
      status: 'processing',
      creditsSpent: cost,
    });

    let result;
    if (provider === 'openai') {
      result = await openai.generateImage({ prompt, size });
    } else if (provider === 'stability') {
      result = await stability.generateImage({ prompt });
    } else {
      return res.status(400).json({ error: `Unsupported image provider: ${provider}` });
    }

    gen.status = 'completed';
    gen.resultUrl = result.url || `data:image/png;base64,${result.b64}`;
    await gen.save();

    res.json({ generation: gen });
  } catch (err) {
    handleGenerationError(res, err);
  }
});

// POST /api/generate/text-to-video
router.post('/text-to-video', requireAuth, async (req, res) => {
  const { prompt, provider = 'openai', seconds = 5 } = req.body;
  const cost = CREDIT_COST['text-to-video'];

  try {
    await spendCredits(req.userId, cost);
    const gen = await Generation.create({
      user: req.userId,
      type: 'text-to-video',
      provider,
      prompt,
      status: 'processing',
      creditsSpent: cost,
    });

    let job;
    if (provider === 'openai') {
      job = await openai.createVideoJob({ prompt, seconds });
    } else if (provider === 'runway') {
      job = await runway.createTextToVideo({ promptText: prompt, duration: seconds });
    } else if (provider === 'luma' || provider === 'pika') {
      job = await luma.createGeneration({ prompt });
    } else {
      return res.status(400).json({ error: `Unsupported video provider: ${provider}` });
    }

    gen.providerJobId = job.providerJobId;
    await gen.save();

    // Video jobs are async - client should poll GET /api/generate/status/:id
    res.status(202).json({ generation: gen });
  } catch (err) {
    handleGenerationError(res, err);
  }
});

// POST /api/generate/image-to-video
router.post('/image-to-video', requireAuth, async (req, res) => {
  const { imageUrl, prompt, provider = 'runway', seconds = 5 } = req.body;
  const cost = CREDIT_COST['image-to-video'];

  try {
    await spendCredits(req.userId, cost);
    const gen = await Generation.create({
      user: req.userId,
      type: 'image-to-video',
      provider,
      prompt,
      inputImageUrl: imageUrl,
      status: 'processing',
      creditsSpent: cost,
    });

    let job;
    if (provider === 'runway') {
      job = await runway.createImageToVideo({ promptImageUrl: imageUrl, promptText: prompt, duration: seconds });
    } else if (provider === 'luma' || provider === 'pika') {
      job = await luma.createGeneration({ prompt, imageUrl });
    } else {
      return res.status(400).json({ error: `Unsupported provider for image-to-video: ${provider}` });
    }

    gen.providerJobId = job.providerJobId;
    await gen.save();

    res.status(202).json({ generation: gen });
  } catch (err) {
    handleGenerationError(res, err);
  }
});

// POST /api/generate/remix - restyle/edit an existing image or video
router.post('/remix', requireAuth, async (req, res) => {
  const { type, sourceUrl, prompt, provider } = req.body; // type: 'image' | 'video'
  const cost = CREDIT_COST.remix;

  try {
    await spendCredits(req.userId, cost);
    const gen = await Generation.create({
      user: req.userId,
      type: 'remix',
      provider: provider || (type === 'video' ? 'runway' : 'stability'),
      prompt,
      inputImageUrl: type === 'image' ? sourceUrl : undefined,
      sourceVideoUrl: type === 'video' ? sourceUrl : undefined,
      status: 'processing',
      creditsSpent: cost,
    });

    if (type === 'image') {
      const { data } = await axios.get(sourceUrl, { responseType: 'arraybuffer' });
      const result = await stability.editImage({ imageBuffer: Buffer.from(data), prompt });
      gen.status = 'completed';
      gen.resultUrl = `data:image/png;base64,${result.b64}`;
      await gen.save();
      return res.json({ generation: gen });
    }

    if (type === 'video') {
      const job = await runway.createVideoToVideo({ videoUrl: sourceUrl, promptText: prompt });
      gen.providerJobId = job.providerJobId;
      await gen.save();
      return res.status(202).json({ generation: gen }); // poll /status/:id
    }

    return res.status(400).json({ error: "type must be 'image' or 'video'" });
  } catch (err) {
    handleGenerationError(res, err);
  }
});

// GET /api/generate/status/:id - poll an async video job
router.get('/status/:id', requireAuth, async (req, res) => {
  try {
    const gen = await Generation.findOne({ _id: req.params.id, user: req.userId });
    if (!gen) return res.status(404).json({ error: 'Generation not found' });
    if (gen.status === 'completed' || gen.status === 'failed') return res.json({ generation: gen });

    let providerStatus;
    if (gen.provider === 'openai') {
      providerStatus = await openai.getVideoJob(gen.providerJobId);
      if (providerStatus.status === 'completed') {
        gen.status = 'completed';
        gen.resultUrl = providerStatus.result_url;
      } else if (providerStatus.status === 'failed') {
        gen.status = 'failed';
        gen.error = providerStatus.error || 'Generation failed';
      }
    } else if (gen.provider === 'runway') {
      providerStatus = await runway.getTask(gen.providerJobId);
      if (providerStatus.status === 'SUCCEEDED') {
        gen.status = 'completed';
        gen.resultUrl = providerStatus.output?.[0];
      } else if (providerStatus.status === 'FAILED') {
        gen.status = 'failed';
        gen.error = providerStatus.failure || 'Generation failed';
      }
    } else if (gen.provider === 'luma' || gen.provider === 'pika') {
      providerStatus = await luma.getGeneration(gen.providerJobId);
      if (providerStatus.state === 'completed') {
        gen.status = 'completed';
        gen.resultUrl = providerStatus.assets?.video;
      } else if (providerStatus.state === 'failed') {
        gen.status = 'failed';
        gen.error = 'Generation failed';
      }
    }

    await gen.save();
    res.json({ generation: gen });
  } catch (err) {
    handleGenerationError(res, err);
  }
});

// GET /api/generate/history - user's past generations
router.get('/history', requireAuth, async (req, res) => {
  const items = await Generation.find({ user: req.userId }).sort({ createdAt: -1 }).limit(50);
  res.json({ items });
});

function handleGenerationError(res, err) {
  if (err.code === 'INSUFFICIENT_CREDITS') {
    return res.status(402).json({ error: err.message });
  }
  console.error(err);
  res.status(500).json({ error: 'Generation failed', detail: err.message });
}

module.exports = router;

const express = require('express');
const requireAuth = require('../middleware/auth');
const User = require('../models/User');
const paystack = require('../services/paystack');
const flutterwave = require('../services/flutterwave');
const grey = require('../services/grey');

const router = express.Router();

// How many credits 1 unit of local currency buys via a Grey/Fin.com bank
// transfer top-up - keep this in step with the PACKAGES pricing below.
const NGN_PER_CREDIT = 25;

// Credit/plan packages - adjust pricing to taste (amounts in NGN).
const PACKAGES = {
  credits_100: { credits: 100, amountNGN: 2500 },
  credits_500: { credits: 500, amountNGN: 10000 },
  plan_pro: { credits: 1000, amountNGN: 15000, plan: 'pro' },
  plan_studio: { credits: 5000, amountNGN: 50000, plan: 'studio' },
};

// POST /api/payments/paystack/initialize
router.post('/paystack/initialize', requireAuth, async (req, res) => {
  try {
    const { packageId } = req.body;
    const pkg = PACKAGES[packageId];
    if (!pkg) return res.status(400).json({ error: 'Unknown package' });

    const user = await User.findById(req.userId);
    const data = await paystack.initializeTransaction({
      email: user.email,
      amountKobo: pkg.amountNGN * 100,
      metadata: { userId: user._id.toString(), packageId },
    });
    res.json(data);
  } catch (err) {
    res.status(500).json({ error: 'Could not start payment', detail: err.message });
  }
});

// Paystack webhook - mount with express.raw() in index.js so signature check works
router.post('/paystack/webhook', async (req, res) => {
  const signature = req.headers['x-paystack-signature'];
  const valid = paystack.verifyWebhookSignature(req.body, signature);
  if (!valid) return res.sendStatus(401);

  const event = JSON.parse(req.body.toString());
  if (event.event === 'charge.success') {
    await applyPackageToUser(event.data.metadata.userId, event.data.metadata.packageId);
  }
  res.sendStatus(200);
});

// POST /api/payments/flutterwave/initialize
router.post('/flutterwave/initialize', requireAuth, async (req, res) => {
  try {
    const { packageId, redirectUrl } = req.body;
    const pkg = PACKAGES[packageId];
    if (!pkg) return res.status(400).json({ error: 'Unknown package' });

    const user = await User.findById(req.userId);
    const txRef = `honorlarry-${user._id}-${Date.now()}`;
    const data = await flutterwave.initializePayment({
      txRef,
      amount: pkg.amountNGN,
      email: user.email,
      redirectUrl,
      meta: { userId: user._id.toString(), packageId },
    });
    res.json(data);
  } catch (err) {
    res.status(500).json({ error: 'Could not start payment', detail: err.message });
  }
});

// Flutterwave webhook
router.post('/flutterwave/webhook', express.json(), async (req, res) => {
  const signature = req.headers['verif-hash'];
  const valid = flutterwave.verifyWebhookSignature(signature);
  if (!valid) return res.sendStatus(401);

  const payload = req.body.data;
  if (req.body.event === 'charge.completed' && payload.status === 'successful') {
    await applyPackageToUser(payload.meta.userId, payload.meta.packageId);
  }
  res.sendStatus(200);
});

// POST /api/payments/grey/account - get or create the user's personal
// virtual bank account. Once issued, any bank transfer into it tops up
// their credit balance automatically via the webhook below.
router.post('/grey/account', requireAuth, async (req, res) => {
  try {
    const { currency = 'NGN' } = req.body;
    const user = await User.findById(req.userId);
    if (!user) return res.status(404).json({ error: 'User not found' });

    if (user.greyVirtualAccount?.accountNumber) {
      return res.json({ account: user.greyVirtualAccount });
    }

    if (!user.greyCustomerId) {
      const customer = await grey.createCustomer({
        fullName: user.name,
        email: user.email,
        country: user.country || 'NG',
      });
      user.greyCustomerId = customer.id;
    }

    const va = await grey.createVirtualAccount({ customerId: user.greyCustomerId, currency });

    user.greyVirtualAccount = {
      id: va.id,
      accountNumber: va.account_number || null,
      bankName: va.bank_name || null,
      currency,
    };
    await user.save();

    res.json({ account: user.greyVirtualAccount, status: va.status });
  } catch (err) {
    res.status(500).json({ error: 'Could not create bank account', detail: err.message });
  }
});

// Grey/Fin.com webhook - credits the depositing user the moment a bank
// transfer lands in their virtual account. Mounted with express.raw() in
// index.js so the HMAC signature check below sees the exact bytes sent.
router.post('/grey/webhook', async (req, res) => {
  const signature = req.headers['x-grey-signature'] || req.headers['x-fin-signature'];
  const valid = grey.verifyWebhookSignature(req.body, signature);
  if (!valid) return res.sendStatus(401);

  const event = JSON.parse(req.body.toString());
  if (event.type === 'virtual_account.deposit_received') {
    const { customer_id: customerId, amount } = event.data;
    const user = await User.findOne({ greyCustomerId: customerId });
    if (user) {
      user.credits += Math.floor(amount / NGN_PER_CREDIT);
      await user.save();
    }
  }
  res.sendStatus(200);
});

async function applyPackageToUser(userId, packageId) {
  const pkg = PACKAGES[packageId];
  if (!pkg) return;
  const user = await User.findById(userId);
  if (!user) return;
  user.credits += pkg.credits;
  if (pkg.plan) user.plan = pkg.plan;
  await user.save();
}

module.exports = router;

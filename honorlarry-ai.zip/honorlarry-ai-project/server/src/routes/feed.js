const express = require('express');
const requireAuth = require('../middleware/auth');
const Post = require('../models/Post');
const Generation = require('../models/Generation');

const router = express.Router();

// GET /api/feed - public explore feed, newest first
router.get('/', async (req, res) => {
  const page = parseInt(req.query.page || '1', 10);
  const limit = 20;
  const posts = await Post.find({ isPublic: true })
    .sort({ createdAt: -1 })
    .skip((page - 1) * limit)
    .limit(limit)
    .populate('user', 'name avatarUrl');
  res.json({ posts });
});

// POST /api/feed - share a completed generation to the community
router.post('/', requireAuth, async (req, res) => {
  const { generationId, caption, isPublic = true } = req.body;
  const gen = await Generation.findOne({ _id: generationId, user: req.userId });
  if (!gen || gen.status !== 'completed') {
    return res.status(400).json({ error: 'Generation not found or not completed yet' });
  }

  const post = await Post.create({
    user: req.userId,
    generation: gen._id,
    caption,
    mediaUrl: gen.resultUrl,
    mediaType: gen.type === 'text-to-image' ? 'image' : 'video',
    isPublic,
  });
  res.status(201).json({ post });
});

// POST /api/feed/:id/like
router.post('/:id/like', requireAuth, async (req, res) => {
  const post = await Post.findById(req.params.id);
  if (!post) return res.status(404).json({ error: 'Post not found' });

  const already = post.likes.some((id) => id.toString() === req.userId);
  if (already) {
    post.likes = post.likes.filter((id) => id.toString() !== req.userId);
  } else {
    post.likes.push(req.userId);
  }
  await post.save();
  res.json({ liked: !already, likeCount: post.likes.length });
});

module.exports = router;

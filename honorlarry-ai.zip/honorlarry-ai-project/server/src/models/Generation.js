const mongoose = require('mongoose');

const GenerationSchema = new mongoose.Schema(
  {
    user: { type: mongoose.Schema.Types.ObjectId, ref: 'User', required: true },
    type: {
      type: String,
      enum: ['text-to-image', 'text-to-video', 'image-to-video', 'remix'],
      required: true,
    },
    provider: {
      type: String,
      enum: ['openai', 'runway', 'stability', 'luma', 'pika'],
      required: true,
    },
    prompt: { type: String },
    inputImageUrl: { type: String },
    sourceVideoUrl: { type: String }, // for remix/edit jobs
    status: {
      type: String,
      enum: ['queued', 'processing', 'completed', 'failed'],
      default: 'queued',
    },
    providerJobId: { type: String },
    resultUrl: { type: String },
    creditsSpent: { type: Number, default: 0 },
    error: { type: String },
  },
  { timestamps: true }
);

module.exports = mongoose.model('Generation', GenerationSchema);

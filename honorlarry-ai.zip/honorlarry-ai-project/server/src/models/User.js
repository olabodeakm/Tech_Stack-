const mongoose = require('mongoose');

const UserSchema = new mongoose.Schema(
  {
    name: { type: String, required: true },
    email: { type: String, required: true, unique: true, lowercase: true },
    passwordHash: { type: String, required: true },
    plan: { type: String, enum: ['free', 'pro', 'studio'], default: 'free' },
    credits: { type: Number, default: 20 }, // free starter credits
    avatarUrl: { type: String, default: '' },
    country: { type: String, default: 'NG' },
    // Grey / Fin.com virtual bank account for topping up credits by bank transfer
    greyCustomerId: { type: String, default: null },
    greyVirtualAccount: {
      id: { type: String, default: null },
      accountNumber: { type: String, default: null },
      bankName: { type: String, default: null },
      currency: { type: String, default: null },
    },
  },
  { timestamps: true }
);

module.exports = mongoose.model('User', UserSchema);

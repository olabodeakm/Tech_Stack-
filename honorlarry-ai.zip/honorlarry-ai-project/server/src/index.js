require('dotenv').config();
const express = require('express');
const cors = require('cors');
const connectDB = require('./config/db');

const authRoutes = require('./routes/auth');
const generateRoutes = require('./routes/generate');
const paymentRoutes = require('./routes/payments');
const feedRoutes = require('./routes/feed');

const app = express();

app.use(cors());

// Paystack webhook needs the raw request body for signature verification,
// so raw-body parsing for that one path must be registered BEFORE the
// global express.json() middleware below.
app.use('/api/payments/paystack/webhook', express.raw({ type: '*/*' }));
app.use('/api/payments/grey/webhook', express.raw({ type: '*/*' }));
app.use(express.json({ limit: '25mb' }));

app.use('/api/auth', authRoutes);
app.use('/api/generate', generateRoutes);
app.use('/api/payments', paymentRoutes);
app.use('/api/feed', feedRoutes);

app.get('/health', (req, res) => res.json({ ok: true }));

const PORT = process.env.PORT || 4000;

connectDB().then(() => {
  app.listen(PORT, () => console.log(`Honorlarry AI API running on port ${PORT}`));
});

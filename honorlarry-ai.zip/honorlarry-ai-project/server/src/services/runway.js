const axios = require('axios');

const BASE_URL = 'https://api.dev.runwayml.com/v1';

function client() {
  return axios.create({
    baseURL: BASE_URL,
    headers: {
      Authorization: `Bearer ${process.env.RUNWAY_API_KEY}`,
      'Content-Type': 'application/json',
      'X-Runway-Version': '2024-11-06',
    },
    timeout: 120000,
  });
}

// Image-to-video: Runway's Gen-3/Gen-4 models require a source image.
async function createImageToVideo({ promptImageUrl, promptText, duration = 5, ratio = '1280:720' }) {
  const res = await client().post('/image_to_video', {
    model: 'gen4_turbo',
    promptImage: promptImageUrl,
    promptText,
    duration,
    ratio,
  });
  return { providerJobId: res.data.id, status: res.data.status };
}

// Text-to-video (where supported by the account/model tier).
async function createTextToVideo({ promptText, duration = 5, ratio = '1280:720' }) {
  const res = await client().post('/text_to_video', {
    model: 'gen4_turbo',
    promptText,
    duration,
    ratio,
  });
  return { providerJobId: res.data.id, status: res.data.status };
}

async function getTask(taskId) {
  const res = await client().get(`/tasks/${taskId}`);
  return res.data; // { status: 'RUNNING'|'SUCCEEDED'|'FAILED', output: [url], ... }
}

// Video-to-video restyling (Gen-4 Aleph). Takes an existing clip and a
// text prompt describing the new look/edit.
async function createVideoToVideo({ videoUrl, promptText, ratio = '1280:720' }) {
  const res = await client().post('/video_to_video', {
    model: 'gen4_aleph',
    videoUri: videoUrl,
    promptText,
    ratio,
  });
  return { providerJobId: res.data.id, status: res.data.status };
}

module.exports = { createImageToVideo, createTextToVideo, createVideoToVideo, getTask };

const axios = require('axios');

const BASE_URL = 'https://api.openai.com/v1';

function client() {
  return axios.create({
    baseURL: BASE_URL,
    headers: {
      Authorization: `Bearer ${process.env.OPENAI_API_KEY}`,
      'Content-Type': 'application/json',
    },
    timeout: 120000,
  });
}

// --- Image generation (GPT-image / DALL-E) ---
async function generateImage({ prompt, size = '1024x1024' }) {
  const res = await client().post('/images/generations', {
    model: 'gpt-image-1',
    prompt,
    size,
  });
  // API returns base64 or a URL depending on config; handle both.
  const item = res.data.data[0];
  return { url: item.url || null, b64: item.b64_json || null };
}

// --- Video generation (Honorlarry) ---
// NOTE: OpenAI's video generation API surface has changed multiple times since launch. Check
// OpenAI's current docs (https://platform.openai.com/docs) for the exact
// endpoint/model name before going live, and update this function to match.
async function createVideoJob({ prompt, seconds = 5, size = '1280x720' }) {
  const res = await client().post('/videos', {
    model: 'sora-2',
    prompt,
    seconds,
    size,
  });
  return { providerJobId: res.data.id, status: res.data.status };
}

async function getVideoJob(jobId) {
  const res = await client().get(`/videos/${jobId}`);
  return res.data; // { status, progress, result_url, ... }
}

module.exports = { generateImage, createVideoJob, getVideoJob };

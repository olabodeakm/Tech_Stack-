const axios = require('axios');

const BASE_URL = 'https://api.lumalabs.ai/dream-machine/v1';

function client() {
  return axios.create({
    baseURL: BASE_URL,
    headers: {
      Authorization: `Bearer ${process.env.LUMA_API_KEY}`,
      'Content-Type': 'application/json',
    },
    timeout: 120000,
  });
}

async function createGeneration({ prompt, imageUrl, loop = false, aspectRatio = '16:9' }) {
  const payload = { prompt, loop, aspect_ratio: aspectRatio };
  if (imageUrl) {
    payload.keyframes = { frame0: { type: 'image', url: imageUrl } };
  }
  const res = await client().post('/generations', payload);
  return { providerJobId: res.data.id, status: res.data.state };
}

async function getGeneration(id) {
  const res = await client().get(`/generations/${id}`);
  return res.data; // { state: 'queued'|'dreaming'|'completed'|'failed', assets: { video } }
}

// Pika Labs follows a very similar REST shape; swap BASE_URL / auth header
// and field names per https://docs.pika.art if you use Pika instead.
module.exports = { createGeneration, getGeneration };

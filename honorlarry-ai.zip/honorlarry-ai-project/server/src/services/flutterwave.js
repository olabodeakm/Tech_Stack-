const axios = require('axios');

const BASE_URL = 'https://api.flutterwave.com/v3';

function client() {
  return axios.create({
    baseURL: BASE_URL,
    headers: {
      Authorization: `Bearer ${process.env.FLUTTERWAVE_SECRET_KEY}`,
      'Content-Type': 'application/json',
    },
  });
}

async function initializePayment({ txRef, amount, currency = 'NGN', email, redirectUrl, meta = {} }) {
  const res = await client().post('/payments', {
    tx_ref: txRef,
    amount,
    currency,
    redirect_url: redirectUrl,
    customer: { email },
    meta,
  });
  return res.data.data; // { link }
}

async function verifyTransaction(transactionId) {
  const res = await client().get(`/transactions/${transactionId}/verify`);
  return res.data.data; // { status: 'successful', amount, meta, ... }
}

// Flutterwave webhooks are verified by comparing the 'verif-hash' header
// against the secret hash you set in the Flutterwave dashboard - no HMAC math needed.
function verifyWebhookSignature(signatureHeader) {
  return signatureHeader === process.env.FLUTTERWAVE_WEBHOOK_SECRET;
}

module.exports = { initializePayment, verifyTransaction, verifyWebhookSignature };

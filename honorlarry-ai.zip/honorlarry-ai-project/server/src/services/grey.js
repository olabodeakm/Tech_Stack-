const axios = require('axios');
const crypto = require('crypto');

// Grey rebranded to Fin.com; the public developer docs now live at
// developer.fin.com. Swap GREY_ENV to 'production' when you go live.
const BASE_URL =
  process.env.GREY_ENV === 'production' ? 'https://api.fin.com' : 'https://sandbox.api.fin.com';

let cachedToken = null;
let cachedTokenExpiry = 0;

// Fin.com uses OAuth 2.0 client-credentials - fetch and cache an access token.
async function getAccessToken() {
  if (cachedToken && Date.now() < cachedTokenExpiry - 30000) return cachedToken;

  const res = await axios.post(`${BASE_URL}/oauth/token`, {
    grant_type: 'client_credentials',
    client_id: process.env.GREY_CLIENT_ID,
    client_secret: process.env.GREY_CLIENT_SECRET,
  });

  cachedToken = res.data.access_token;
  cachedTokenExpiry = Date.now() + res.data.expires_in * 1000;
  return cachedToken;
}

async function client() {
  const token = await getAccessToken();
  return axios.create({
    baseURL: BASE_URL,
    headers: {
      Authorization: `Bearer ${token}`,
      'Content-Type': 'application/json',
    },
    timeout: 30000,
  });
}

// Create the underlying customer profile - required once per user before a
// virtual account can be issued.
async function createCustomer({ fullName, email, country }) {
  const api = await client();
  const res = await api.post('/v3/customers', {
    full_name: fullName,
    email,
    country, // ISO country code, e.g. 'NG'
  });
  return res.data; // { id, ... }
}

// Issue a permanent virtual account (NGN, USD, etc.) that this customer can
// receive bank transfers into - deposits land as webhook events.
async function createVirtualAccount({ customerId, currency = 'NGN' }) {
  const api = await client();
  const res = await api.post(`/v3/customers/${customerId}/virtual-accounts`, {
    currency,
  });
  return res.data; // { id, status, account_number, bank_name, ... } once ACTIVE
}

async function getVirtualAccount({ customerId, virtualAccountId }) {
  const api = await client();
  const res = await api.get(`/v3/customers/${customerId}/virtual-accounts/${virtualAccountId}`);
  return res.data;
}

// Fin.com signs webhooks with HMAC-SHA256 over the raw request body.
function verifyWebhookSignature(rawBody, signatureHeader) {
  const hash = crypto
    .createHmac('sha256', process.env.GREY_WEBHOOK_SECRET)
    .update(rawBody)
    .digest('hex');
  return hash === signatureHeader;
}

module.exports = {
  createCustomer,
  createVirtualAccount,
  getVirtualAccount,
  verifyWebhookSignature,
};

const axios = require('axios');
const crypto = require('crypto');

const BASE_URL = 'https://api.paystack.co';

function client() {
  return axios.create({
    baseURL: BASE_URL,
    headers: {
      Authorization: `Bearer ${process.env.PAYSTACK_SECRET_KEY}`,
      'Content-Type': 'application/json',
    },
  });
}

// amount is in the smallest currency unit (kobo for NGN)
async function initializeTransaction({ email, amountKobo, metadata = {} }) {
  const res = await client().post('/transaction/initialize', {
    email,
    amount: amountKobo,
    metadata,
  });
  return res.data.data; // { authorization_url, access_code, reference }
}

async function verifyTransaction(reference) {
  const res = await client().get(`/transaction/verify/${reference}`);
  return res.data.data; // { status: 'success', amount, metadata, ... }
}

function verifyWebhookSignature(rawBody, signatureHeader) {
  const hash = crypto
    .createHmac('sha512', process.env.PAYSTACK_SECRET_KEY)
    .update(rawBody)
    .digest('hex');
  return hash === signatureHeader;
}

module.exports = { initializeTransaction, verifyTransaction, verifyWebhookSignature };

const axios = require('axios');
const FormData = require('form-data');

const BASE_URL = 'https://api.stability.ai/v2beta';

function headers(extra = {}) {
  return {
    Authorization: `Bearer ${process.env.STABILITY_API_KEY}`,
    Accept: 'application/json',
    ...extra,
  };
}

// Text-to-image via Stable Image Core/Ultra
async function generateImage({ prompt, aspectRatio = '1:1' }) {
  const form = new FormData();
  form.append('prompt', prompt);
  form.append('aspect_ratio', aspectRatio);
  form.append('output_format', 'png');

  const res = await axios.post(`${BASE_URL}/stable-image/generate/core`, form, {
    headers: headers(form.getHeaders()),
    responseType: 'json',
    timeout: 120000,
  });
  return { b64: res.data.image, finishReason: res.data.finish_reason };
}

// Image-to-video (Stable Video Diffusion)
async function createImageToVideo({ imageBuffer, cfgScale = 1.8, motionBucketId = 127 }) {
  const form = new FormData();
  form.append('image', imageBuffer, { filename: 'input.png' });
  form.append('cfg_scale', cfgScale);
  form.append('motion_bucket_id', motionBucketId);

  const res = await axios.post(`${BASE_URL}/image-to-video`, form, {
    headers: headers(form.getHeaders()),
    timeout: 120000,
  });
  return { providerJobId: res.data.id };
}

async function getVideoResult(generationId) {
  const res = await axios.get(`${BASE_URL}/image-to-video/result/${generationId}`, {
    headers: headers({ Accept: 'video/*' }),
    responseType: 'arraybuffer',
    validateStatus: () => true,
  });
  if (res.status === 202) return { status: 'processing' };
  if (res.status === 200) return { status: 'completed', videoBuffer: res.data };
  return { status: 'failed', detail: res.data?.toString?.() };
}

// Image-to-image edit/restyle (used by the video-to-video helper too)
async function editImage({ imageBuffer, prompt, strength = 0.65 }) {
  const form = new FormData();
  form.append('image', imageBuffer, { filename: 'input.png' });
  form.append('prompt', prompt);
  form.append('strength', strength);
  form.append('output_format', 'png');

  const res = await axios.post(`${BASE_URL}/stable-image/generate/sd3`, form, {
    headers: headers(form.getHeaders()),
    timeout: 120000,
  });
  return { b64: res.data.image, finishReason: res.data.finish_reason };
}

module.exports = { generateImage, createImageToVideo, getVideoResult, editImage };

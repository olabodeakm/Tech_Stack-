export const colors = {
  background: '#0B0B12',
  surface: '#16161F',
  surfaceAlt: '#1E1E2A',
  primary: '#7C5CFF',
  primaryMuted: '#4B3B99',
  accent: '#FF5CA8',
  text: '#F5F5FA',
  textMuted: '#9A9AB0',
  border: '#2A2A38',
  success: '#3DDC97',
  danger: '#FF5C5C',
};

export default colors;

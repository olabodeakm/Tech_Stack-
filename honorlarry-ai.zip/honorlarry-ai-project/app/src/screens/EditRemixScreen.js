import React, { useState, useRef, useEffect } from 'react';
import { View, Text, TextInput, TouchableOpacity, StyleSheet, Image, ActivityIndicator, Alert, ScrollView } from 'react-native';
import { Video } from 'expo-av';
import * as ImagePicker from 'expo-image-picker';
import { colors } from '../theme/colors';
import { remixContent, pollGenerationStatus, shareToFeed } from '../api/client';
import { maybeShowInterstitialAfterGeneration } from '../ads/MetaAudienceNetwork';
import { AD_PLACEMENTS } from '../ads/AdConfig';

export default function EditRemixScreen() {
  const [mode, setMode] = useState('image'); // 'image' | 'video'
  const [sourceUri, setSourceUri] = useState(null);
  const [prompt, setPrompt] = useState('');
  const [submitting, setSubmitting] = useState(false);
  const [statusText, setStatusText] = useState('');
  const [result, setResult] = useState(null);
  const pollRef = useRef(null);

  useEffect(() => () => pollRef.current && clearInterval(pollRef.current), []);

  async function pickSource() {
    const permission = await ImagePicker.requestMediaLibraryPermissionsAsync();
    if (!permission.granted) return Alert.alert('Permission needed', 'Allow media access to pick a file.');

    const picked = await ImagePicker.launchImageLibraryAsync({
      mediaTypes: mode === 'image' ? ImagePicker.MediaTypeOptions.Images : ImagePicker.MediaTypeOptions.Videos,
      quality: 0.8,
    });
    if (!picked.canceled) setSourceUri(picked.assets[0].uri);
  }

  async function handleGenerate() {
    if (!sourceUri) return Alert.alert('Pick a file', `Choose the ${mode} you want to remix first.`);
    if (!prompt.trim()) return Alert.alert('Add a prompt', 'Describe the new style or edit you want.');

    setSubmitting(true);
    setResult(null);
    setStatusText('Applying your edit...');
    try {
      // NOTE: sourceUri is a local device path here - upload it to your own
      // storage first in production and pass the resulting public URL.
      const gen = await remixContent(mode, sourceUri, prompt);
      if (gen.status === 'completed') {
        setResult(gen);
        setSubmitting(false);
        setStatusText('');
        maybeShowInterstitialAfterGeneration(AD_PLACEMENTS.generationInterstitial);
      } else {
        setStatusText('Rendering your remix - this can take a minute or two...');
        startPolling(gen._id);
      }
    } catch (err) {
      Alert.alert('Remix failed', err?.response?.data?.error || err.message);
      setSubmitting(false);
      setStatusText('');
    }
  }

  function startPolling(id) {
    pollRef.current = setInterval(async () => {
      try {
        const gen = await pollGenerationStatus(id);
        if (gen.status === 'completed') {
          clearInterval(pollRef.current);
          setResult(gen);
          setSubmitting(false);
          setStatusText('');
          maybeShowInterstitialAfterGeneration(AD_PLACEMENTS.generationInterstitial);
        } else if (gen.status === 'failed') {
          clearInterval(pollRef.current);
          setSubmitting(false);
          setStatusText('');
          Alert.alert('Remix failed', gen.error || 'The provider could not complete this job.');
        }
      } catch (err) {
        clearInterval(pollRef.current);
        setSubmitting(false);
      }
    }, 4000);
  }

  async function handleShare() {
    try {
      await shareToFeed(result._id, prompt);
      Alert.alert('Shared', 'Your remix is now on the Explore feed.');
    } catch (err) {
      Alert.alert('Could not share', err?.response?.data?.error || err.message);
    }
  }

  return (
    <ScrollView style={styles.container} contentContainerStyle={{ padding: 20 }}>
      <Text style={styles.title}>Edit & Remix</Text>

      <View style={styles.providerRow}>
        {['image', 'video'].map((m) => (
          <TouchableOpacity
            key={m}
            style={[styles.providerChip, mode === m && styles.providerChipActive]}
            onPress={() => {
              setMode(m);
              setSourceUri(null);
              setResult(null);
            }}
          >
            <Text style={[styles.providerText, mode === m && styles.providerTextActive]}>
              Remix {m === 'image' ? 'an image' : 'a video'}
            </Text>
          </TouchableOpacity>
        ))}
      </View>

      <TouchableOpacity style={styles.picker} onPress={pickSource}>
        {sourceUri ? (
          mode === 'image' ? (
            <Image source={{ uri: sourceUri }} style={styles.pickedMedia} resizeMode="cover" />
          ) : (
            <Video source={{ uri: sourceUri }} style={styles.pickedMedia} resizeMode="cover" useNativeControls />
          )
        ) : (
          <Text style={styles.pickerText}>Tap to choose a {mode}</Text>
        )}
      </TouchableOpacity>

      <TextInput
        style={styles.textArea}
        placeholder="Restyle as a watercolor painting... / Change the background to a sunset beach..."
        placeholderTextColor={colors.textMuted}
        multiline
        value={prompt}
        onChangeText={setPrompt}
      />

      <TouchableOpacity style={styles.primaryBtn} onPress={handleGenerate} disabled={submitting}>
        {submitting ? <ActivityIndicator color="#fff" /> : <Text style={styles.primaryBtnText}>Remix (6 credits)</Text>}
      </TouchableOpacity>

      {!!statusText && <Text style={styles.statusText}>{statusText}</Text>}

      {result?.resultUrl && (
        <View style={styles.resultCard}>
          {mode === 'image' ? (
            <Image source={{ uri: result.resultUrl }} style={styles.resultMedia} resizeMode="cover" />
          ) : (
            <Video source={{ uri: result.resultUrl }} style={styles.resultMedia} useNativeControls resizeMode="cover" isLooping />
          )}
          <TouchableOpacity style={styles.shareBtn} onPress={handleShare}>
            <Text style={styles.shareBtnText}>Share to Explore</Text>
          </TouchableOpacity>
        </View>
      )}
    </ScrollView>
  );
}

const styles = StyleSheet.create({
  container: { flex: 1, backgroundColor: colors.background },
  title: { color: colors.text, fontSize: 22, fontWeight: '700', marginBottom: 16 },
  providerRow: { flexDirection: 'row', gap: 10, marginBottom: 16 },
  providerChip: { paddingVertical: 8, paddingHorizontal: 14, borderRadius: 20, borderWidth: 1, borderColor: colors.border },
  providerChipActive: { backgroundColor: colors.primary, borderColor: colors.primary },
  providerText: { color: colors.textMuted },
  providerTextActive: { color: '#fff', fontWeight: '700' },
  picker: {
    height: 200,
    borderRadius: 16,
    backgroundColor: colors.surface,
    borderWidth: 1,
    borderColor: colors.border,
    alignItems: 'center',
    justifyContent: 'center',
    marginBottom: 16,
    overflow: 'hidden',
  },
  pickedMedia: { width: '100%', height: '100%' },
  pickerText: { color: colors.textMuted },
  textArea: {
    backgroundColor: colors.surface,
    borderRadius: 14,
    padding: 16,
    color: colors.text,
    minHeight: 100,
    textAlignVertical: 'top',
    borderWidth: 1,
    borderColor: colors.border,
  },
  primaryBtn: { backgroundColor: colors.primary, borderRadius: 14, paddingVertical: 16, alignItems: 'center', marginTop: 16 },
  primaryBtnText: { color: '#fff', fontWeight: '700' },
  statusText: { color: colors.textMuted, textAlign: 'center', marginTop: 14 },
  resultCard: { marginTop: 24 },
  resultMedia: { width: '100%', aspectRatio: 16 / 9, borderRadius: 16, backgroundColor: colors.surface },
  shareBtn: { marginTop: 12, backgroundColor: colors.surfaceAlt, borderRadius: 14, paddingVertical: 14, alignItems: 'center' },
  shareBtnText: { color: colors.text, fontWeight: '600' },
});

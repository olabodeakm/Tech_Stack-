import React, { useState } from 'react';
import { View, Text, TouchableOpacity, StyleSheet, ScrollView, Linking, Alert, ActivityIndicator, Clipboard } from 'react-native';
import { colors } from '../theme/colors';
import { startPaystackPayment, startFlutterwavePayment, getGreyAccount } from '../api/client';

const PACKAGES = [
  { id: 'credits_100', label: '100 credits', price: '₦2,500' },
  { id: 'credits_500', label: '500 credits', price: '₦10,000' },
  { id: 'plan_pro', label: 'Pro plan · 1,000 credits/mo', price: '₦15,000' },
  { id: 'plan_studio', label: 'Studio plan · 5,000 credits/mo', price: '₦50,000' },
];

export default function SubscriptionScreen() {
  const [loadingId, setLoadingId] = useState(null);
  const [greyAccount, setGreyAccount] = useState(null);
  const [loadingGrey, setLoadingGrey] = useState(false);

  async function payWithPaystack(pkg) {
    setLoadingId(pkg.id);
    try {
      const { authorization_url } = await startPaystackPayment(pkg.id);
      Linking.openURL(authorization_url);
    } catch (err) {
      Alert.alert('Payment failed to start', err?.response?.data?.error || err.message);
    } finally {
      setLoadingId(null);
    }
  }

  async function payWithFlutterwave(pkg) {
    setLoadingId(pkg.id);
    try {
      const { link } = await startFlutterwavePayment(pkg.id, 'honorlarry://payment-complete');
      Linking.openURL(link);
    } catch (err) {
      Alert.alert('Payment failed to start', err?.response?.data?.error || err.message);
    } finally {
      setLoadingId(null);
    }
  }

  async function loadGreyAccount() {
    setLoadingGrey(true);
    try {
      const account = await getGreyAccount('NGN');
      setGreyAccount(account);
    } catch (err) {
      Alert.alert('Could not get account', err?.response?.data?.error || err.message);
    } finally {
      setLoadingGrey(false);
    }
  }

  return (
    <ScrollView style={styles.container} contentContainerStyle={{ padding: 20 }}>
      <Text style={styles.title}>Top up & plans</Text>

      {PACKAGES.map((pkg) => (
        <View key={pkg.id} style={styles.pkgCard}>
          <View style={{ flex: 1 }}>
            <Text style={styles.pkgLabel}>{pkg.label}</Text>
            <Text style={styles.pkgPrice}>{pkg.price}</Text>
          </View>
          <View style={styles.pkgActions}>
            <TouchableOpacity style={styles.payBtn} onPress={() => payWithPaystack(pkg)} disabled={!!loadingId}>
              {loadingId === pkg.id ? <ActivityIndicator color="#fff" /> : <Text style={styles.payBtnText}>Paystack</Text>}
            </TouchableOpacity>
            <TouchableOpacity style={[styles.payBtn, styles.payBtnAlt]} onPress={() => payWithFlutterwave(pkg)} disabled={!!loadingId}>
              <Text style={styles.payBtnText}>Flutterwave</Text>
            </TouchableOpacity>
          </View>
        </View>
      ))}

      <View style={styles.greySection}>
        <Text style={styles.greyTitle}>🏦 Pay by bank transfer (Grey)</Text>
        <Text style={styles.greySubtitle}>
          Get your own dedicated account number. Any transfer you send tops up your credits automatically —
          ₦{25} = 1 credit.
        </Text>

        {!greyAccount ? (
          <TouchableOpacity style={styles.primaryBtn} onPress={loadGreyAccount} disabled={loadingGrey}>
            {loadingGrey ? <ActivityIndicator color="#fff" /> : <Text style={styles.primaryBtnText}>Get my account number</Text>}
          </TouchableOpacity>
        ) : (
          <View style={styles.accountBox}>
            <Text style={styles.accountLabel}>Bank</Text>
            <Text style={styles.accountValue}>{greyAccount.bankName || 'Pending activation'}</Text>
            <Text style={styles.accountLabel}>Account number</Text>
            <View style={styles.accountRow}>
              <Text style={styles.accountValue}>{greyAccount.accountNumber || 'Pending activation'}</Text>
              {!!greyAccount.accountNumber && (
                <TouchableOpacity
                  onPress={() => {
                    Clipboard.setString(greyAccount.accountNumber);
                    Alert.alert('Copied', 'Account number copied to clipboard.');
                  }}
                >
                  <Text style={styles.copyText}>Copy</Text>
                </TouchableOpacity>
              )}
            </View>
          </View>
        )}
      </View>
    </ScrollView>
  );
}

const styles = StyleSheet.create({
  container: { flex: 1, backgroundColor: colors.background },
  title: { color: colors.text, fontSize: 22, fontWeight: '700', marginBottom: 20 },
  pkgCard: {
    backgroundColor: colors.surface,
    borderRadius: 16,
    padding: 16,
    borderWidth: 1,
    borderColor: colors.border,
    marginBottom: 12,
  },
  pkgLabel: { color: colors.text, fontWeight: '700', fontSize: 15 },
  pkgPrice: { color: colors.textMuted, marginTop: 2 },
  pkgActions: { flexDirection: 'row', gap: 10, marginTop: 12 },
  payBtn: { flex: 1, backgroundColor: colors.primary, borderRadius: 12, paddingVertical: 10, alignItems: 'center' },
  payBtnAlt: { backgroundColor: colors.accent },
  payBtnText: { color: '#fff', fontWeight: '700', fontSize: 12 },
  greySection: {
    marginTop: 12,
    backgroundColor: colors.surfaceAlt,
    borderRadius: 18,
    padding: 18,
    borderWidth: 1,
    borderColor: colors.border,
  },
  greyTitle: { color: colors.text, fontSize: 16, fontWeight: '700' },
  greySubtitle: { color: colors.textMuted, marginTop: 6, marginBottom: 16, lineHeight: 18 },
  primaryBtn: { backgroundColor: colors.primary, borderRadius: 14, paddingVertical: 14, alignItems: 'center' },
  primaryBtnText: { color: '#fff', fontWeight: '700' },
  accountBox: { backgroundColor: colors.surface, borderRadius: 12, padding: 14 },
  accountLabel: { color: colors.textMuted, fontSize: 12, marginTop: 8 },
  accountValue: { color: colors.text, fontSize: 16, fontWeight: '700', marginTop: 2 },
  accountRow: { flexDirection: 'row', justifyContent: 'space-between', alignItems: 'center' },
  copyText: { color: colors.primary, fontWeight: '700' },
});

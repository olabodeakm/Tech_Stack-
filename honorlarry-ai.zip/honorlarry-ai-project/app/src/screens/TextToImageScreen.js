import React, { useState } from 'react';
import { View, Text, TextInput, TouchableOpacity, StyleSheet, Image, ActivityIndicator, Alert, ScrollView } from 'react-native';
import { colors } from '../theme/colors';
import { generateTextToImage, shareToFeed } from '../api/client';
import { maybeShowInterstitialAfterGeneration } from '../ads/MetaAudienceNetwork';
import { AD_PLACEMENTS } from '../ads/AdConfig';

const PROVIDERS = [
  { id: 'openai', label: 'OpenAI' },
  { id: 'stability', label: 'Stability AI' },
];

export default function TextToImageScreen() {
  const [prompt, setPrompt] = useState('');
  const [provider, setProvider] = useState('openai');
  const [loading, setLoading] = useState(false);
  const [result, setResult] = useState(null);

  async function handleGenerate() {
    if (!prompt.trim()) return Alert.alert('Add a prompt', 'Describe the image you want first.');
    setLoading(true);
    setResult(null);
    try {
      const gen = await generateTextToImage(prompt, provider);
      setResult(gen);
      maybeShowInterstitialAfterGeneration(AD_PLACEMENTS.generationInterstitial);
    } catch (err) {
      Alert.alert('Generation failed', err?.response?.data?.error || err.message);
    } finally {
      setLoading(false);
    }
  }

  async function handleShare() {
    try {
      await shareToFeed(result._id, prompt);
      Alert.alert('Shared', 'Your image is now on the Explore feed.');
    } catch (err) {
      Alert.alert('Could not share', err?.response?.data?.error || err.message);
    }
  }

  return (
    <ScrollView style={styles.container} contentContainerStyle={{ padding: 20 }}>
      <Text style={styles.title}>Text to Image</Text>

      <View style={styles.providerRow}>
        {PROVIDERS.map((p) => (
          <TouchableOpacity
            key={p.id}
            style={[styles.providerChip, provider === p.id && styles.providerChipActive]}
            onPress={() => setProvider(p.id)}
          >
            <Text style={[styles.providerText, provider === p.id && styles.providerTextActive]}>{p.label}</Text>
          </TouchableOpacity>
        ))}
      </View>

      <TextInput
        style={styles.textArea}
        placeholder="A neon-lit market street in Lagos at night, cinematic..."
        placeholderTextColor={colors.textMuted}
        multiline
        value={prompt}
        onChangeText={setPrompt}
      />

      <TouchableOpacity style={styles.primaryBtn} onPress={handleGenerate} disabled={loading}>
        {loading ? <ActivityIndicator color="#fff" /> : <Text style={styles.primaryBtnText}>Generate (2 credits)</Text>}
      </TouchableOpacity>

      {result?.resultUrl && (
        <View style={styles.resultCard}>
          <Image source={{ uri: result.resultUrl }} style={styles.resultImage} resizeMode="cover" />
          <TouchableOpacity style={styles.shareBtn} onPress={handleShare}>
            <Text style={styles.shareBtnText}>Share to Explore</Text>
          </TouchableOpacity>
        </View>
      )}
    </ScrollView>
  );
}

const styles = StyleSheet.create({
  container: { flex: 1, backgroundColor: colors.background },
  title: { color: colors.text, fontSize: 22, fontWeight: '700', marginBottom: 16 },
  providerRow: { flexDirection: 'row', gap: 10, marginBottom: 16 },
  providerChip: { paddingVertical: 8, paddingHorizontal: 14, borderRadius: 20, borderWidth: 1, borderColor: colors.border },
  providerChipActive: { backgroundColor: colors.primary, borderColor: colors.primary },
  providerText: { color: colors.textMuted },
  providerTextActive: { color: '#fff', fontWeight: '700' },
  textArea: {
    backgroundColor: colors.surface,
    borderRadius: 14,
    padding: 16,
    color: colors.text,
    minHeight: 120,
    textAlignVertical: 'top',
    borderWidth: 1,
    borderColor: colors.border,
  },
  primaryBtn: { backgroundColor: colors.primary, borderRadius: 14, paddingVertical: 16, alignItems: 'center', marginTop: 16 },
  primaryBtnText: { color: '#fff', fontWeight: '700' },
  resultCard: { marginTop: 24 },
  resultImage: { width: '100%', aspectRatio: 1, borderRadius: 16, backgroundColor: colors.surface },
  shareBtn: { marginTop: 12, backgroundColor: colors.surfaceAlt, borderRadius: 14, paddingVertical: 14, alignItems: 'center' },
  shareBtnText: { color: colors.text, fontWeight: '600' },
});

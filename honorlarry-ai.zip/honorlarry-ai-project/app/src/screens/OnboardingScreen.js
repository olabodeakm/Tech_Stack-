import React from 'react';
import { View, Text, StyleSheet, TouchableOpacity } from 'react-native';
import { colors } from '../theme/colors';

export default function OnboardingScreen({ navigation }) {
  return (
    <View style={styles.container}>
      <Text style={styles.logo}>Honorlarry AI</Text>
      <Text style={styles.tagline}>Turn your words into images and video.</Text>

      <View style={styles.card}>
        <Text style={styles.cardTitle}>✨ Text to Image</Text>
        <Text style={styles.cardTitle}>🎬 Text to Video</Text>
        <Text style={styles.cardTitle}>🖼️ Image to Video</Text>
        <Text style={styles.cardTitle}>✂️ Edit & Remix</Text>
        <Text style={styles.cardTitle}>🌍 Community Feed</Text>
      </View>

      <TouchableOpacity style={styles.primaryBtn} onPress={() => navigation.replace('Register')}>
        <Text style={styles.primaryBtnText}>Get Started</Text>
      </TouchableOpacity>
      <TouchableOpacity onPress={() => navigation.replace('Login')}>
        <Text style={styles.secondaryText}>I already have an account</Text>
      </TouchableOpacity>
    </View>
  );
}

const styles = StyleSheet.create({
  container: { flex: 1, backgroundColor: colors.background, padding: 24, justifyContent: 'center' },
  logo: { fontSize: 40, fontWeight: '800', color: colors.text, textAlign: 'center' },
  tagline: { color: colors.textMuted, textAlign: 'center', marginTop: 8, marginBottom: 32 },
  card: {
    backgroundColor: colors.surface,
    borderRadius: 20,
    padding: 20,
    borderWidth: 1,
    borderColor: colors.border,
    gap: 12,
    marginBottom: 32,
  },
  cardTitle: { color: colors.text, fontSize: 16 },
  primaryBtn: { backgroundColor: colors.primary, borderRadius: 16, paddingVertical: 16, alignItems: 'center' },
  primaryBtnText: { color: '#fff', fontWeight: '700', fontSize: 16 },
  secondaryText: { color: colors.textMuted, textAlign: 'center', marginTop: 16 },
});

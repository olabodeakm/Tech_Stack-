import React from 'react';
import { View, Text, StyleSheet, TouchableOpacity, ScrollView } from 'react-native';
import { colors } from '../theme/colors';
import AdBanner from '../components/AdBanner';
import { AD_PLACEMENTS } from '../ads/AdConfig';

const TOOLS = [
  { key: 'TextToImage', icon: '✨', title: 'Text to Image', subtitle: 'Describe it, we render it' },
  { key: 'TextToVideo', icon: '🎬', title: 'Text to Video', subtitle: 'Prompts become motion' },
  { key: 'ImageToVideo', icon: '🖼️', title: 'Image to Video', subtitle: 'Animate a still photo' },
  { key: 'EditRemix', icon: '✂️', title: 'Edit & Remix', subtitle: 'Restyle existing clips' },
  { key: 'ExploreFeed', icon: '🌍', title: 'Explore', subtitle: 'See what the community made' },
];

export default function HomeScreen({ navigation }) {
  return (
    <ScrollView style={styles.container} contentContainerStyle={{ padding: 20 }}>
      <View style={styles.header}>
        <Text style={styles.greeting}>What will you create today?</Text>
        <TouchableOpacity onPress={() => navigation.navigate('Profile')}>
          <Text style={styles.profileIcon}>👤</Text>
        </TouchableOpacity>
      </View>

      <View style={styles.grid}>
        {TOOLS.map((tool) => (
          <TouchableOpacity key={tool.key} style={styles.card} onPress={() => navigation.navigate(tool.key)}>
            <Text style={styles.cardIcon}>{tool.icon}</Text>
            <Text style={styles.cardTitle}>{tool.title}</Text>
            <Text style={styles.cardSubtitle}>{tool.subtitle}</Text>
          </TouchableOpacity>
        ))}
      </View>

      <TouchableOpacity style={styles.upgradeBanner} onPress={() => navigation.navigate('Subscription')}>
        <Text style={styles.upgradeTitle}>Need more credits?</Text>
        <Text style={styles.upgradeSubtitle}>Top up or upgrade your plan →</Text>
      </TouchableOpacity>

      <AdBanner placementId={AD_PLACEMENTS.homeBanner} />
    </ScrollView>
  );
}

const styles = StyleSheet.create({
  container: { flex: 1, backgroundColor: colors.background },
  header: { flexDirection: 'row', justifyContent: 'space-between', alignItems: 'center', marginBottom: 20 },
  greeting: { color: colors.text, fontSize: 22, fontWeight: '700', flex: 1 },
  profileIcon: { fontSize: 24 },
  grid: { gap: 14 },
  card: {
    backgroundColor: colors.surface,
    borderRadius: 18,
    padding: 18,
    borderWidth: 1,
    borderColor: colors.border,
  },
  cardIcon: { fontSize: 28, marginBottom: 8 },
  cardTitle: { color: colors.text, fontSize: 17, fontWeight: '700' },
  cardSubtitle: { color: colors.textMuted, fontSize: 13, marginTop: 2 },
  upgradeBanner: {
    marginTop: 20,
    backgroundColor: colors.primaryMuted,
    borderRadius: 18,
    padding: 18,
  },
  upgradeTitle: { color: colors.text, fontWeight: '700', fontSize: 16 },
  upgradeSubtitle: { color: colors.text, opacity: 0.8, marginTop: 4 },
});

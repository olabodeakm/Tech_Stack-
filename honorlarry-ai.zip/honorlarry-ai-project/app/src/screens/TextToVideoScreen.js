import React, { useState, useRef, useEffect } from 'react';
import { View, Text, TextInput, TouchableOpacity, StyleSheet, ActivityIndicator, Alert, ScrollView } from 'react-native';
import { Video } from 'expo-av';
import { colors } from '../theme/colors';
import { generateTextToVideo, pollGenerationStatus, shareToFeed } from '../api/client';
import { maybeShowInterstitialAfterGeneration } from '../ads/MetaAudienceNetwork';
import { AD_PLACEMENTS } from '../ads/AdConfig';

const PROVIDERS = [
  { id: 'openai', label: 'Sora (OpenAI)' },
  { id: 'runway', label: 'Runway' },
  { id: 'luma', label: 'Luma' },
];

export default function TextToVideoScreen() {
  const [prompt, setPrompt] = useState('');
  const [provider, setProvider] = useState('openai');
  const [seconds, setSeconds] = useState(5);
  const [submitting, setSubmitting] = useState(false);
  const [statusText, setStatusText] = useState('');
  const [result, setResult] = useState(null);
  const pollRef = useRef(null);

  useEffect(() => () => pollRef.current && clearInterval(pollRef.current), []);

  async function handleGenerate() {
    if (!prompt.trim()) return Alert.alert('Add a prompt', 'Describe the video you want first.');
    setSubmitting(true);
    setResult(null);
    setStatusText('Sending to model...');
    try {
      const gen = await generateTextToVideo(prompt, provider, seconds);
      setStatusText('Rendering your video - this can take a minute or two...');
      startPolling(gen._id);
    } catch (err) {
      Alert.alert('Generation failed', err?.response?.data?.error || err.message);
      setSubmitting(false);
      setStatusText('');
    }
  }

  function startPolling(id) {
    pollRef.current = setInterval(async () => {
      try {
        const gen = await pollGenerationStatus(id);
        if (gen.status === 'completed') {
          clearInterval(pollRef.current);
          setResult(gen);
          setSubmitting(false);
          setStatusText('');
          maybeShowInterstitialAfterGeneration(AD_PLACEMENTS.generationInterstitial);
        } else if (gen.status === 'failed') {
          clearInterval(pollRef.current);
          setSubmitting(false);
          setStatusText('');
          Alert.alert('Generation failed', gen.error || 'The provider could not complete this job.');
        }
      } catch (err) {
        clearInterval(pollRef.current);
        setSubmitting(false);
      }
    }, 4000);
  }

  async function handleShare() {
    try {
      await shareToFeed(result._id, prompt);
      Alert.alert('Shared', 'Your video is now on the Explore feed.');
    } catch (err) {
      Alert.alert('Could not share', err?.response?.data?.error || err.message);
    }
  }

  return (
    <ScrollView style={styles.container} contentContainerStyle={{ padding: 20 }}>
      <Text style={styles.title}>Text to Video</Text>

      <View style={styles.providerRow}>
        {PROVIDERS.map((p) => (
          <TouchableOpacity
            key={p.id}
            style={[styles.providerChip, provider === p.id && styles.providerChipActive]}
            onPress={() => setProvider(p.id)}
          >
            <Text style={[styles.providerText, provider === p.id && styles.providerTextActive]}>{p.label}</Text>
          </TouchableOpacity>
        ))}
      </View>

      <View style={styles.providerRow}>
        {[5, 8, 10].map((s) => (
          <TouchableOpacity key={s} style={[styles.durationChip, seconds === s && styles.providerChipActive]} onPress={() => setSeconds(s)}>
            <Text style={[styles.providerText, seconds === s && styles.providerTextActive]}>{s}s</Text>
          </TouchableOpacity>
        ))}
      </View>

      <TextInput
        style={styles.textArea}
        placeholder="A drone shot flying over Zuma Rock at sunrise..."
        placeholderTextColor={colors.textMuted}
        multiline
        value={prompt}
        onChangeText={setPrompt}
      />

      <TouchableOpacity style={styles.primaryBtn} onPress={handleGenerate} disabled={submitting}>
        {submitting ? <ActivityIndicator color="#fff" /> : <Text style={styles.primaryBtnText}>Generate (10 credits)</Text>}
      </TouchableOpacity>

      {!!statusText && <Text style={styles.statusText}>{statusText}</Text>}

      {result?.resultUrl && (
        <View style={styles.resultCard}>
          <Video
            source={{ uri: result.resultUrl }}
            style={styles.resultVideo}
            useNativeControls
            resizeMode="cover"
            isLooping
          />
          <TouchableOpacity style={styles.shareBtn} onPress={handleShare}>
            <Text style={styles.shareBtnText}>Share to Explore</Text>
          </TouchableOpacity>
        </View>
      )}
    </ScrollView>
  );
}

const styles = StyleSheet.create({
  container: { flex: 1, backgroundColor: colors.background },
  title: { color: colors.text, fontSize: 22, fontWeight: '700', marginBottom: 16 },
  providerRow: { flexDirection: 'row', gap: 10, marginBottom: 16, flexWrap: 'wrap' },
  providerChip: { paddingVertical: 8, paddingHorizontal: 14, borderRadius: 20, borderWidth: 1, borderColor: colors.border },
  durationChip: { paddingVertical: 8, paddingHorizontal: 16, borderRadius: 20, borderWidth: 1, borderColor: colors.border },
  providerChipActive: { backgroundColor: colors.primary, borderColor: colors.primary },
  providerText: { color: colors.textMuted },
  providerTextActive: { color: '#fff', fontWeight: '700' },
  textArea: {
    backgroundColor: colors.surface,
    borderRadius: 14,
    padding: 16,
    color: colors.text,
    minHeight: 120,
    textAlignVertical: 'top',
    borderWidth: 1,
    borderColor: colors.border,
  },
  primaryBtn: { backgroundColor: colors.primary, borderRadius: 14, paddingVertical: 16, alignItems: 'center', marginTop: 16 },
  primaryBtnText: { color: '#fff', fontWeight: '700' },
  statusText: { color: colors.textMuted, textAlign: 'center', marginTop: 14 },
  resultCard: { marginTop: 24 },
  resultVideo: { width: '100%', aspectRatio: 16 / 9, borderRadius: 16, backgroundColor: colors.surface },
  shareBtn: { marginTop: 12, backgroundColor: colors.surfaceAlt, borderRadius: 14, paddingVertical: 14, alignItems: 'center' },
  shareBtnText: { color: colors.text, fontWeight: '600' },
});

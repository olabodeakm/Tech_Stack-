import React, { useState, useEffect, useCallback } from 'react';
import { View, Text, StyleSheet, FlatList, Image, TouchableOpacity, RefreshControl, ActivityIndicator } from 'react-native';
import { Video } from 'expo-av';
import { colors } from '../theme/colors';
import { getFeed, toggleLike } from '../api/client';
import AdBanner from '../components/AdBanner';
import { AD_PLACEMENTS } from '../ads/AdConfig';

export default function ExploreFeedScreen() {
  const [posts, setPosts] = useState([]);
  const [loading, setLoading] = useState(true);
  const [refreshing, setRefreshing] = useState(false);

  const load = useCallback(async () => {
    try {
      const items = await getFeed(1);
      setPosts(items);
    } finally {
      setLoading(false);
      setRefreshing(false);
    }
  }, []);

  useEffect(() => {
    load();
  }, [load]);

  async function handleLike(postId) {
    // optimistic update
    setPosts((prev) =>
      prev.map((p) => (p._id === postId ? { ...p, likes: [...(p.likes || []), 'me'] } : p))
    );
    try {
      await toggleLike(postId);
    } catch {
      // ignore - a pull-to-refresh will resync counts
    }
  }

  if (loading) {
    return (
      <View style={styles.centered}>
        <ActivityIndicator color={colors.primary} />
      </View>
    );
  }

  return (
    <FlatList
      style={styles.container}
      contentContainerStyle={{ padding: 20 }}
      data={posts}
      keyExtractor={(item) => item._id}
      refreshControl={
        <RefreshControl
          refreshing={refreshing}
          onRefresh={() => {
            setRefreshing(true);
            load();
          }}
          tintColor={colors.primary}
        />
      }
      ListEmptyComponent={
        <View style={styles.centered}>
          <Text style={styles.emptyText}>Nothing here yet — be the first to share a creation!</Text>
        </View>
      }
      ListHeaderComponent={<AdBanner placementId={AD_PLACEMENTS.exploreBanner} />}
      renderItem={({ item }) => (
        <View style={styles.card}>
          {item.mediaType === 'video' ? (
            <Video source={{ uri: item.mediaUrl }} style={styles.media} useNativeControls resizeMode="cover" isLooping />
          ) : (
            <Image source={{ uri: item.mediaUrl }} style={styles.media} resizeMode="cover" />
          )}
          <View style={styles.cardFooter}>
            <View style={{ flex: 1 }}>
              <Text style={styles.authorName}>{item.user?.name || 'Someone'}</Text>
              {!!item.caption && <Text style={styles.caption} numberOfLines={2}>{item.caption}</Text>}
            </View>
            <TouchableOpacity style={styles.likeBtn} onPress={() => handleLike(item._id)}>
              <Text style={styles.likeText}>❤️ {item.likes?.length || 0}</Text>
            </TouchableOpacity>
          </View>
        </View>
      )}
    />
  );
}

const styles = StyleSheet.create({
  container: { flex: 1, backgroundColor: colors.background },
  centered: { flex: 1, alignItems: 'center', justifyContent: 'center', padding: 40 },
  emptyText: { color: colors.textMuted, textAlign: 'center' },
  card: {
    backgroundColor: colors.surface,
    borderRadius: 18,
    marginBottom: 18,
    overflow: 'hidden',
    borderWidth: 1,
    borderColor: colors.border,
  },
  media: { width: '100%', aspectRatio: 1 },
  cardFooter: { flexDirection: 'row', alignItems: 'center', padding: 14 },
  authorName: { color: colors.text, fontWeight: '700' },
  caption: { color: colors.textMuted, marginTop: 2 },
  likeBtn: { paddingHorizontal: 12, paddingVertical: 8, backgroundColor: colors.surfaceAlt, borderRadius: 20 },
  likeText: { color: colors.text, fontWeight: '600' },
});

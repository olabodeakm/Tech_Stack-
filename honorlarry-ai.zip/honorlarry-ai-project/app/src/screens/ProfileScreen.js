import React, { useState, useEffect, useCallback } from 'react';
import { View, Text, StyleSheet, TouchableOpacity, FlatList, ActivityIndicator, Image } from 'react-native';
import { colors } from '../theme/colors';
import { getMe, getHistory, logout } from '../api/client';

const TYPE_LABEL = {
  'text-to-image': 'Text → Image',
  'text-to-video': 'Text → Video',
  'image-to-video': 'Image → Video',
  remix: 'Edit & Remix',
};

export default function ProfileScreen({ navigation }) {
  const [user, setUser] = useState(null);
  const [history, setHistory] = useState([]);
  const [loading, setLoading] = useState(true);

  const load = useCallback(async () => {
    try {
      const [me, items] = await Promise.all([getMe(), getHistory()]);
      setUser(me);
      setHistory(items);
    } finally {
      setLoading(false);
    }
  }, []);

  useEffect(() => {
    load();
  }, [load]);

  async function handleLogout() {
    await logout();
    navigation.reset({ index: 0, routes: [{ name: 'Onboarding' }] });
  }

  if (loading) {
    return (
      <View style={styles.centered}>
        <ActivityIndicator color={colors.primary} />
      </View>
    );
  }

  return (
    <FlatList
      style={styles.container}
      contentContainerStyle={{ padding: 20 }}
      data={history}
      keyExtractor={(item) => item._id}
      ListHeaderComponent={
        <View>
          <View style={styles.header}>
            <View style={styles.avatarPlaceholder}>
              <Text style={styles.avatarInitial}>{user?.name?.[0]?.toUpperCase() || '?'}</Text>
            </View>
            <Text style={styles.name}>{user?.name}</Text>
            <Text style={styles.email}>{user?.email}</Text>
          </View>

          <View style={styles.statsRow}>
            <View style={styles.statCard}>
              <Text style={styles.statValue}>{user?.credits ?? 0}</Text>
              <Text style={styles.statLabel}>Credits</Text>
            </View>
            <View style={styles.statCard}>
              <Text style={styles.statValue}>{user?.plan}</Text>
              <Text style={styles.statLabel}>Plan</Text>
            </View>
          </View>

          <TouchableOpacity style={styles.primaryBtn} onPress={() => navigation.navigate('Subscription')}>
            <Text style={styles.primaryBtnText}>Manage plan & top up</Text>
          </TouchableOpacity>

          <Text style={styles.sectionTitle}>Your creations</Text>
        </View>
      }
      ListEmptyComponent={
        <Text style={styles.emptyText}>You haven't generated anything yet.</Text>
      }
      renderItem={({ item }) => (
        <View style={styles.historyRow}>
          {item.resultUrl && item.type !== 'text-to-video' && item.type !== 'image-to-video' ? (
            <Image source={{ uri: item.resultUrl }} style={styles.historyThumb} />
          ) : (
            <View style={[styles.historyThumb, styles.historyThumbPlaceholder]}>
              <Text style={{ fontSize: 18 }}>🎬</Text>
            </View>
          )}
          <View style={{ flex: 1 }}>
            <Text style={styles.historyType}>{TYPE_LABEL[item.type] || item.type}</Text>
            <Text style={styles.historyPrompt} numberOfLines={1}>{item.prompt}</Text>
          </View>
          <Text style={styles.historyStatus}>{item.status}</Text>
        </View>
      )}
      ListFooterComponent={
        <TouchableOpacity style={styles.logoutBtn} onPress={handleLogout}>
          <Text style={styles.logoutText}>Log out</Text>
        </TouchableOpacity>
      }
    />
  );
}

const styles = StyleSheet.create({
  container: { flex: 1, backgroundColor: colors.background },
  centered: { flex: 1, alignItems: 'center', justifyContent: 'center', backgroundColor: colors.background },
  header: { alignItems: 'center', marginBottom: 20 },
  avatarPlaceholder: {
    width: 72,
    height: 72,
    borderRadius: 36,
    backgroundColor: colors.primary,
    alignItems: 'center',
    justifyContent: 'center',
    marginBottom: 12,
  },
  avatarInitial: { color: '#fff', fontSize: 28, fontWeight: '700' },
  name: { color: colors.text, fontSize: 18, fontWeight: '700' },
  email: { color: colors.textMuted, marginTop: 2 },
  statsRow: { flexDirection: 'row', gap: 12, marginBottom: 16 },
  statCard: {
    flex: 1,
    backgroundColor: colors.surface,
    borderRadius: 14,
    padding: 16,
    alignItems: 'center',
    borderWidth: 1,
    borderColor: colors.border,
  },
  statValue: { color: colors.text, fontSize: 20, fontWeight: '700', textTransform: 'capitalize' },
  statLabel: { color: colors.textMuted, marginTop: 4, fontSize: 12 },
  primaryBtn: { backgroundColor: colors.primary, borderRadius: 14, paddingVertical: 14, alignItems: 'center', marginBottom: 24 },
  primaryBtnText: { color: '#fff', fontWeight: '700' },
  sectionTitle: { color: colors.text, fontSize: 16, fontWeight: '700', marginBottom: 12 },
  emptyText: { color: colors.textMuted, textAlign: 'center', marginTop: 20 },
  historyRow: {
    flexDirection: 'row',
    alignItems: 'center',
    gap: 12,
    backgroundColor: colors.surface,
    borderRadius: 14,
    padding: 12,
    marginBottom: 10,
    borderWidth: 1,
    borderColor: colors.border,
  },
  historyThumb: { width: 48, height: 48, borderRadius: 10, backgroundColor: colors.surfaceAlt },
  historyThumbPlaceholder: { alignItems: 'center', justifyContent: 'center' },
  historyType: { color: colors.text, fontWeight: '600', fontSize: 13 },
  historyPrompt: { color: colors.textMuted, fontSize: 12, marginTop: 2 },
  historyStatus: { color: colors.textMuted, fontSize: 11, textTransform: 'capitalize' },
  logoutBtn: { marginTop: 20, marginBottom: 40, alignItems: 'center' },
  logoutText: { color: colors.danger, fontWeight: '700' },
});

import React, { useState, useRef, useEffect } from 'react';
import { View, Text, TextInput, TouchableOpacity, StyleSheet, Image, ActivityIndicator, Alert, ScrollView } from 'react-native';
import { Video } from 'expo-av';
import * as ImagePicker from 'expo-image-picker';
import { colors } from '../theme/colors';
import { generateImageToVideo, pollGenerationStatus, shareToFeed } from '../api/client';
import { maybeShowInterstitialAfterGeneration } from '../ads/MetaAudienceNetwork';
import { AD_PLACEMENTS } from '../ads/AdConfig';

const PROVIDERS = [
  { id: 'runway', label: 'Runway' },
  { id: 'luma', label: 'Luma' },
];

export default function ImageToVideoScreen() {
  const [imageUri, setImageUri] = useState(null);
  const [prompt, setPrompt] = useState('');
  const [provider, setProvider] = useState('runway');
  const [submitting, setSubmitting] = useState(false);
  const [statusText, setStatusText] = useState('');
  const [result, setResult] = useState(null);
  const pollRef = useRef(null);

  useEffect(() => () => pollRef.current && clearInterval(pollRef.current), []);

  async function pickImage() {
    const permission = await ImagePicker.requestMediaLibraryPermissionsAsync();
    if (!permission.granted) return Alert.alert('Permission needed', 'Allow photo access to pick an image.');

    const result = await ImagePicker.launchImageLibraryAsync({
      mediaTypes: ImagePicker.MediaTypeOptions.Images,
      quality: 0.8,
    });
    if (!result.canceled) setImageUri(result.assets[0].uri);
  }

  async function handleGenerate() {
    if (!imageUri) return Alert.alert('Pick a photo', 'Choose the image you want to animate first.');
    setSubmitting(true);
    setResult(null);
    setStatusText('Uploading and starting animation...');
    try {
      // NOTE: imageUri is a local file:// URI here. In production, upload it
      // to your own storage (e.g. Cloudinary/S3) first and pass that public
      // URL to the API - providers need a reachable image URL, not a device path.
      const gen = await generateImageToVideo(imageUri, prompt, provider);
      setStatusText('Animating your photo - this can take a minute or two...');
      startPolling(gen._id);
    } catch (err) {
      Alert.alert('Generation failed', err?.response?.data?.error || err.message);
      setSubmitting(false);
      setStatusText('');
    }
  }

  function startPolling(id) {
    pollRef.current = setInterval(async () => {
      try {
        const gen = await pollGenerationStatus(id);
        if (gen.status === 'completed') {
          clearInterval(pollRef.current);
          setResult(gen);
          setSubmitting(false);
          setStatusText('');
          maybeShowInterstitialAfterGeneration(AD_PLACEMENTS.generationInterstitial);
        } else if (gen.status === 'failed') {
          clearInterval(pollRef.current);
          setSubmitting(false);
          setStatusText('');
          Alert.alert('Generation failed', gen.error || 'The provider could not complete this job.');
        }
      } catch (err) {
        clearInterval(pollRef.current);
        setSubmitting(false);
      }
    }, 4000);
  }

  async function handleShare() {
    try {
      await shareToFeed(result._id, prompt);
      Alert.alert('Shared', 'Your video is now on the Explore feed.');
    } catch (err) {
      Alert.alert('Could not share', err?.response?.data?.error || err.message);
    }
  }

  return (
    <ScrollView style={styles.container} contentContainerStyle={{ padding: 20 }}>
      <Text style={styles.title}>Image to Video</Text>

      <TouchableOpacity style={styles.imagePicker} onPress={pickImage}>
        {imageUri ? (
          <Image source={{ uri: imageUri }} style={styles.pickedImage} resizeMode="cover" />
        ) : (
          <Text style={styles.imagePickerText}>Tap to choose a photo</Text>
        )}
      </TouchableOpacity>

      <View style={styles.providerRow}>
        {PROVIDERS.map((p) => (
          <TouchableOpacity
            key={p.id}
            style={[styles.providerChip, provider === p.id && styles.providerChipActive]}
            onPress={() => setProvider(p.id)}
          >
            <Text style={[styles.providerText, provider === p.id && styles.providerTextActive]}>{p.label}</Text>
          </TouchableOpacity>
        ))}
      </View>

      <TextInput
        style={styles.textArea}
        placeholder="Describe the motion - e.g. gentle wind, camera slowly zooms in..."
        placeholderTextColor={colors.textMuted}
        multiline
        value={prompt}
        onChangeText={setPrompt}
      />

      <TouchableOpacity style={styles.primaryBtn} onPress={handleGenerate} disabled={submitting}>
        {submitting ? <ActivityIndicator color="#fff" /> : <Text style={styles.primaryBtnText}>Animate (8 credits)</Text>}
      </TouchableOpacity>

      {!!statusText && <Text style={styles.statusText}>{statusText}</Text>}

      {result?.resultUrl && (
        <View style={styles.resultCard}>
          <Video source={{ uri: result.resultUrl }} style={styles.resultVideo} useNativeControls resizeMode="cover" isLooping />
          <TouchableOpacity style={styles.shareBtn} onPress={handleShare}>
            <Text style={styles.shareBtnText}>Share to Explore</Text>
          </TouchableOpacity>
        </View>
      )}
    </ScrollView>
  );
}

const styles = StyleSheet.create({
  container: { flex: 1, backgroundColor: colors.background },
  title: { color: colors.text, fontSize: 22, fontWeight: '700', marginBottom: 16 },
  imagePicker: {
    height: 220,
    borderRadius: 16,
    backgroundColor: colors.surface,
    borderWidth: 1,
    borderColor: colors.border,
    alignItems: 'center',
    justifyContent: 'center',
    marginBottom: 16,
    overflow: 'hidden',
  },
  pickedImage: { width: '100%', height: '100%' },
  imagePickerText: { color: colors.textMuted },
  providerRow: { flexDirection: 'row', gap: 10, marginBottom: 16 },
  providerChip: { paddingVertical: 8, paddingHorizontal: 14, borderRadius: 20, borderWidth: 1, borderColor: colors.border },
  providerChipActive: { backgroundColor: colors.primary, borderColor: colors.primary },
  providerText: { color: colors.textMuted },
  providerTextActive: { color: '#fff', fontWeight: '700' },
  textArea: {
    backgroundColor: colors.surface,
    borderRadius: 14,
    padding: 16,
    color: colors.text,
    minHeight: 100,
    textAlignVertical: 'top',
    borderWidth: 1,
    borderColor: colors.border,
  },
  primaryBtn: { backgroundColor: colors.primary, borderRadius: 14, paddingVertical: 16, alignItems: 'center', marginTop: 16 },
  primaryBtnText: { color: '#fff', fontWeight: '700' },
  statusText: { color: colors.textMuted, textAlign: 'center', marginTop: 14 },
  resultCard: { marginTop: 24 },
  resultVideo: { width: '100%', aspectRatio: 16 / 9, borderRadius: 16, backgroundColor: colors.surface },
  shareBtn: { marginTop: 12, backgroundColor: colors.surfaceAlt, borderRadius: 14, paddingVertical: 14, alignItems: 'center' },
  shareBtnText: { color: colors.text, fontWeight: '600' },
});

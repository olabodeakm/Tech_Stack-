// Meta Audience Network placement IDs.
//
// Create these in: Meta Audience Network > Monetization Manager > your app
// > Placements. Each placement ID looks like "1234567890_9876543210"
// (your App ID + placement ID). Paste the real values in below - the
// placeholders here will only ever return test/no-fill ads.
export const AD_PLACEMENTS = {
  homeBanner: 'YOUR_APP_ID_HOME_BANNER_PLACEMENT_ID',
  exploreBanner: 'YOUR_APP_ID_EXPLORE_BANNER_PLACEMENT_ID',
  generationInterstitial: 'YOUR_APP_ID_INTERSTITIAL_PLACEMENT_ID',
};

// While developing, add your device's hash here so you see clearly-marked
// TEST ads instead of live ads (which can get your account flagged for
// invalid traffic). The first time you run the app, Meta logs your
// device's hash to the console - copy it in here.
// See: https://developers.facebook.com/docs/audience-network/testing
export const TEST_DEVICE_HASHES = [];

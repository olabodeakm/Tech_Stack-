import { AdSettings, InterstitialAdManager } from 'react-native-fbads';
import { TEST_DEVICE_HASHES } from './AdConfig';

let initialized = false;

// Registers test devices so ads show in "test mode" during development.
// Safe to call multiple times - only runs once.
export function initAds() {
  if (initialized) return;
  TEST_DEVICE_HASHES.forEach((hash) => AdSettings.addTestDevice(hash));
  initialized = true;
}

// Shows a full-screen interstitial ad. Resolves to `true`/`false` for
// whether the user tapped it, or `false` if the ad simply couldn't be
// shown (no fill, network issue, app not yet approved for ads). This
// never throws - a failed ad should never block the user's flow.
export async function showInterstitial(placementId) {
  initAds();
  try {
    const didClick = await InterstitialAdManager.showAd(placementId);
    return didClick;
  } catch (err) {
    console.warn('Interstitial ad not shown:', err?.message || err);
    return false;
  }
}

// Preloads an interstitial so it's ready to show instantly later - call
// this a few seconds before you expect to need showInterstitial().
export function preloadInterstitial(placementId) {
  initAds();
  InterstitialAdManager.preloadAd(placementId).catch(() => {
    // Preload failures are silent - showInterstitial will just load fresh.
  });
}

// Frequency cap: showing a full-screen ad after every single generation is
// against most ad networks' spirit (and annoys paying-in-credits users).
// This shows an interstitial only every Nth completed generation, tracked
// per app session. Tune INTERVAL to taste.
const INTERVAL = 3;
let completedGenerationCount = 0;

export async function maybeShowInterstitialAfterGeneration(placementId) {
  completedGenerationCount += 1;
  if (completedGenerationCount % INTERVAL !== 0) return false;
  return showInterstitial(placementId);
}

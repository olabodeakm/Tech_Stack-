import axios from 'axios';
import * as SecureStore from 'expo-secure-store';
import Constants from 'expo-constants';

const API_BASE_URL = Constants.expoConfig?.extra?.apiBaseUrl || 'http://localhost:4000/api';

const api = axios.create({ baseURL: API_BASE_URL, timeout: 60000 });

api.interceptors.request.use(async (config) => {
  const token = await SecureStore.getItemAsync('authToken');
  if (token) config.headers.Authorization = `Bearer ${token}`;
  return config;
});

export async function register(name, email, password) {
  const { data } = await api.post('/auth/register', { name, email, password });
  await SecureStore.setItemAsync('authToken', data.token);
  return data.user;
}

export async function login(email, password) {
  const { data } = await api.post('/auth/login', { email, password });
  await SecureStore.setItemAsync('authToken', data.token);
  return data.user;
}

export async function logout() {
  await SecureStore.deleteItemAsync('authToken');
}

export async function getMe() {
  const { data } = await api.get('/auth/me');
  return data.user;
}

export async function generateTextToImage(prompt, provider = 'openai') {
  const { data } = await api.post('/generate/text-to-image', { prompt, provider });
  return data.generation;
}

export async function generateTextToVideo(prompt, provider = 'openai', seconds = 5) {
  const { data } = await api.post('/generate/text-to-video', { prompt, provider, seconds });
  return data.generation;
}

export async function generateImageToVideo(imageUrl, prompt, provider = 'runway') {
  const { data } = await api.post('/generate/image-to-video', { imageUrl, prompt, provider });
  return data.generation;
}

export async function remixContent(type, sourceUrl, prompt, provider) {
  const { data } = await api.post('/generate/remix', { type, sourceUrl, prompt, provider });
  return data.generation;
}

export async function pollGenerationStatus(id) {
  const { data } = await api.get(`/generate/status/${id}`);
  return data.generation;
}

export async function getHistory() {
  const { data } = await api.get('/generate/history');
  return data.items;
}

export async function getFeed(page = 1) {
  const { data } = await api.get(`/feed?page=${page}`);
  return data.posts;
}

export async function shareToFeed(generationId, caption) {
  const { data } = await api.post('/feed', { generationId, caption });
  return data.post;
}

export async function toggleLike(postId) {
  const { data } = await api.post(`/feed/${postId}/like`);
  return data;
}

export async function startPaystackPayment(packageId) {
  const { data } = await api.post('/payments/paystack/initialize', { packageId });
  return data; // { authorization_url }
}

export async function startFlutterwavePayment(packageId, redirectUrl) {
  const { data } = await api.post('/payments/flutterwave/initialize', { packageId, redirectUrl });
  return data; // { link }
}

export async function getGreyAccount(currency = 'NGN') {
  const { data } = await api.post('/payments/grey/account', { currency });
  return data.account; // { accountNumber, bankName, currency }
}

export default api;

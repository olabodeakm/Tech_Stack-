import React, { useState } from 'react';
import { View, StyleSheet } from 'react-native';
import { BannerView } from 'react-native-fbads';
import { colors } from '../theme/colors';

// Renders a Meta Audience Network banner. If the placement has no fill
// (common in dev/before approval) or errors, it collapses to nothing
// instead of leaving an awkward empty box in the layout.
export default function AdBanner({ placementId, type = 'standard' }) {
  const [failed, setFailed] = useState(false);

  if (!placementId || failed) return null;

  return (
    <View style={styles.wrap}>
      <BannerView placementId={placementId} type={type} onError={() => setFailed(true)} />
    </View>
  );
}

const styles = StyleSheet.create({
  wrap: {
    alignItems: 'center',
    justifyContent: 'center',
    marginVertical: 12,
    backgroundColor: colors.surface,
    borderRadius: 14,
    overflow: 'hidden',
    borderWidth: 1,
    borderColor: colors.border,
  },
});

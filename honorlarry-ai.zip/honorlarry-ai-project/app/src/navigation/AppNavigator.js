import React from 'react';
import { createNativeStackNavigator } from '@react-navigation/native-stack';
import { colors } from '../theme/colors';

import OnboardingScreen from '../screens/OnboardingScreen';
import LoginScreen from '../screens/LoginScreen';
import RegisterScreen from '../screens/RegisterScreen';
import HomeScreen from '../screens/HomeScreen';
import TextToImageScreen from '../screens/TextToImageScreen';
import TextToVideoScreen from '../screens/TextToVideoScreen';
import ImageToVideoScreen from '../screens/ImageToVideoScreen';
import EditRemixScreen from '../screens/EditRemixScreen';
import ExploreFeedScreen from '../screens/ExploreFeedScreen';
import ProfileScreen from '../screens/ProfileScreen';
import SubscriptionScreen from '../screens/SubscriptionScreen';

const Stack = createNativeStackNavigator();

const screenOptions = {
  headerStyle: { backgroundColor: colors.background },
  headerTintColor: colors.text,
  headerShadowVisible: false,
  contentStyle: { backgroundColor: colors.background },
};

export default function AppNavigator({ initialRouteName }) {
  return (
    <Stack.Navigator initialRouteName={initialRouteName} screenOptions={screenOptions}>
      <Stack.Screen name="Onboarding" component={OnboardingScreen} options={{ headerShown: false }} />
      <Stack.Screen name="Login" component={LoginScreen} options={{ headerShown: false }} />
      <Stack.Screen name="Register" component={RegisterScreen} options={{ headerShown: false }} />

      <Stack.Screen name="Home" component={HomeScreen} options={{ headerShown: false }} />
      <Stack.Screen name="TextToImage" component={TextToImageScreen} options={{ title: 'Text to Image' }} />
      <Stack.Screen name="TextToVideo" component={TextToVideoScreen} options={{ title: 'Text to Video' }} />
      <Stack.Screen name="ImageToVideo" component={ImageToVideoScreen} options={{ title: 'Image to Video' }} />
      <Stack.Screen name="EditRemix" component={EditRemixScreen} options={{ title: 'Edit & Remix' }} />
      <Stack.Screen name="ExploreFeed" component={ExploreFeedScreen} options={{ title: 'Explore' }} />
      <Stack.Screen name="Profile" component={ProfileScreen} options={{ title: 'Profile' }} />
      <Stack.Screen name="Subscription" component={SubscriptionScreen} options={{ title: 'Top up & plans' }} />
    </Stack.Navigator>
  );
}

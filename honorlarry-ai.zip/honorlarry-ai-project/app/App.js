import React, { useEffect, useState } from 'react';
import { View, ActivityIndicator, StatusBar } from 'react-native';
import { NavigationContainer } from '@react-navigation/native';
import * as SecureStore from 'expo-secure-store';
import AppNavigator from './src/navigation/AppNavigator';
import { colors } from './src/theme/colors';
import { initAds } from './src/ads/MetaAudienceNetwork';

export default function App() {
  const [checkingSession, setCheckingSession] = useState(true);
  const [initialRouteName, setInitialRouteName] = useState('Onboarding');

  useEffect(() => {
    // Registers Meta Audience Network test devices (a no-op list until you
    // add your own device hash in src/ads/AdConfig.js). Wrapped so a missing
    // native module in an unbuilt/Expo Go session can't crash startup.
    try {
      initAds();
    } catch (err) {
      console.warn('Ad init skipped:', err?.message || err);
    }

    (async () => {
      const token = await SecureStore.getItemAsync('authToken');
      setInitialRouteName(token ? 'Home' : 'Onboarding');
      setCheckingSession(false);
    })();
  }, []);

  if (checkingSession) {
    return (
      <View style={{ flex: 1, alignItems: 'center', justifyContent: 'center', backgroundColor: colors.background }}>
        <ActivityIndicator color={colors.primary} size="large" />
      </View>
    );
  }

  return (
    <NavigationContainer>
      <StatusBar barStyle="light-content" backgroundColor={colors.background} />
      <AppNavigator initialRouteName={initialRouteName} />
    </NavigationContainer>
  );
}
